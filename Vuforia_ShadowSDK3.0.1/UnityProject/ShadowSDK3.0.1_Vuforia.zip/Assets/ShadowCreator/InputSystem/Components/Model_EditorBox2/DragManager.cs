﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DragManager: MonoBehaviour
{
    public GameObject focusRotModel;
    public GameObject focusScalModel;
    public GameObject eulerGame;
    public GameObject scaleGame;
    public Material LineMaterial;
    public Material boxMaterial;
    public Material boxClickMaterial;

}
