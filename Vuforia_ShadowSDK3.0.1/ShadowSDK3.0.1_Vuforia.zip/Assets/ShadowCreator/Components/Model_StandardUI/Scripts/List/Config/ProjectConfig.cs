﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class ProjectConfig : ProjectBaseConfig
{
    public ProjectConfig(BaseList baseList, List<BaseConfig> configs) : base(baseList, configs) {
    }
}