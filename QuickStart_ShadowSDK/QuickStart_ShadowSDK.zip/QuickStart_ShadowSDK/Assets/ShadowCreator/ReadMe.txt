# ShadowSDK3.0.1
ShadowCreator UnitySDK

SDK version number: ShadowSDK3.0.1

Recommended Unity Version:2019.2.3f1

Github: https://github.com/ShadowCreatorSDK/ShadowSDK3.0.1

OfficialWebsite: http://www.shadowcreator.com/

Documents:ShadowCreator/Documents/

API Documents:ShadowCreator/API/Documents/API Release Notes

If you have any Questions,Contact chaoqun.wang@ivglass.com